# 🤝 Contribuir a MoneyNest

¡Gracias por tu interés en contribuir! Este documento te guiará en el proceso.

---

## 📋 Código de Conducta

Al participar en este proyecto, aceptas mantener un ambiente respetuoso y profesional.

---

## 🐛 Reportar Bugs

### Antes de reportar:
1. Busca si el bug ya fue reportado en [Issues](https://github.com/tu-usuario/moneynest/issues)
2. Verifica que estés usando la última versión
3. Intenta reproducir el bug

### Cómo reportar:
1. Ve a [Issues → New Issue](https://github.com/tu-usuario/moneynest/issues/new)
2. Usa la plantilla de Bug Report
3. Incluye:
   - Descripción clara del problema
   - Pasos para reproducir
   - Comportamiento esperado vs actual
   - Screenshots (si aplica)
   - Navegador y versión
   - Logs de consola (si hay errores)

---

## 💡 Sugerir Features

### Proceso:
1. Abre un [Issue](https://github.com/tu-usuario/moneynest/issues/new)
2. Usa la plantilla de Feature Request
3. Describe:
   - ¿Qué problema resuelve?
   - ¿Cómo funcionaría?
   - ¿Por qué es importante?
4. Espera feedback de mantenedores

---

## 🔧 Contribuir Código

### Setup Local:

```bash
# 1. Fork el repositorio
# Clic en "Fork" en GitHub

# 2. Clonar tu fork
git clone https://github.com/TU-USUARIO/moneynest.git
cd moneynest

# 3. Añadir upstream
git remote add upstream https://github.com/ORIGINAL-USER/moneynest.git

# 4. Crear rama para tu feature
git checkout -b feature/mi-nueva-feature

# 5. Hacer cambios...

# 6. Commit
git add .
git commit -m "feat: Añadir nueva feature X"

# 7. Push
git push origin feature/mi-nueva-feature

# 8. Crear Pull Request en GitHub
```

### Guía de Commits:

Usamos [Conventional Commits](https://www.conventionalcommits.org/):

```
feat: Nueva característica
fix: Corrección de bug
docs: Cambios en documentación
style: Formato, punto y coma, etc (no afecta código)
refactor: Refactorización de código
test: Añadir o corregir tests
chore: Tareas de mantenimiento
```

**Ejemplos:**
```bash
git commit -m "feat: Añadir modo multi-moneda"
git commit -m "fix: Corregir cálculo de balance en dashboard"
git commit -m "docs: Actualizar README con nuevas features"
```

---

## 📁 Estructura del Proyecto

```
moneynest/
├── public/
│   ├── index.html          # App principal
│   ├── manifest.json       # PWA manifest
│   ├── service-worker.js   # Service Worker
│   └── icons/              # Iconos PWA
├── firestore.rules         # Reglas de seguridad
├── firebase.json           # Config Firebase
├── README.md              # Documentación principal
├── DEPLOY.md              # Guía de deploy
└── CONTRIBUTING.md        # Esta guía
```

---

## ✅ Checklist antes de PR:

```
☐ El código funciona localmente
☐ No hay errores en consola
☐ Probado en Chrome, Firefox, Safari
☐ Probado en móvil (responsive)
☐ Commit messages siguen convención
☐ Actualizada documentación (si aplica)
☐ No hay código comentado innecesario
☐ Variables y funciones tienen nombres claros
☐ No hay console.log() de debug
```

---

## 🎨 Guía de Estilo

### **CSS:**
```css
/* Usar variables CSS */
:root {
  --primary-color: #10B981;
}

/* Nombres descriptivos */
.btn-primary { }  /* ✅ Bueno */
.b1 { }           /* ❌ Malo */

/* Mobile-first */
.elemento {
  /* Estilos móvil */
}

@media (min-width: 768px) {
  .elemento {
    /* Estilos desktop */
  }
}
```

### **JavaScript:**
```javascript
// Usar const/let, no var
const totalIngresos = calcularIngresos();

// Nombres descriptivos
function calcularBalance() { }  // ✅ Bueno
function cb() { }               // ❌ Malo

// Comentarios cuando sea necesario
// Calcula el balance neto considerando todos los ingresos y gastos
function calcularBalanceNeto() {
  // ...
}

// Arrow functions para callbacks
datos.ingresos.map(ingreso => ingreso.monto);
```

---

## 🧪 Testing

Por ahora MoneyNest no tiene tests automáticos, pero **debes probar manualmente**:

1. ✅ Login y registro
2. ✅ CRUD de ingresos/gastos/inversiones
3. ✅ Cálculos (balance, presupuestos, etc)
4. ✅ Gráficos se renderizan
5. ✅ Export CSV funciona
6. ✅ Dark mode toggle
7. ✅ PWA se puede instalar
8. ✅ Funciona offline

---

## 📚 Recursos

- [Firebase Docs](https://firebase.google.com/docs)
- [Chart.js Docs](https://www.chartjs.org/docs/)
- [PWA Guide](https://web.dev/progressive-web-apps/)
- [JavaScript Style Guide](https://github.com/airbnb/javascript)

---

## ❓ ¿Dudas?

- Abre un [Discussion](https://github.com/tu-usuario/moneynest/discussions)
- O crea un Issue con la etiqueta `question`

---

## 🎉 ¡Gracias!

Cada contribución hace a MoneyNest mejor. Tu tiempo y esfuerzo son muy apreciados.

**Happy coding! 💰🚀**
