# Iconos PWA

Esta carpeta debe contener los iconos de la aplicación en diferentes tamaños.

## 📦 Iconos Requeridos:

```
icons/
├── icon-72x72.png
├── icon-96x96.png
├── icon-128x128.png
├── icon-144x144.png
├── icon-152x152.png
├── icon-192x192.png
├── icon-384x384.png
└── icon-512x512.png
```

## 🎨 Cómo Generar:

### Opción 1: Generador Online (Recomendado)
1. Ve a https://realfavicongenerator.net/
2. Sube tu logo (idealmente 512x512px o más)
3. Configura opciones
4. Descarga y extrae en esta carpeta

### Opción 2: Manualmente
1. Crea un logo cuadrado (1024x1024px recomendado)
2. Usa herramienta de redimensionado (Photoshop, GIMP, etc)
3. Exporta en los tamaños listados arriba
4. Guarda como PNG con transparencia

## ✅ Checklist:

```
☐ Todos los tamaños generados
☐ Formato PNG
☐ Transparencia (si aplica)
☐ Nombres exactos según manifest.json
☐ Probado en móvil
```

## 🎯 Logo MoneyNest:

**Colores:**
- Principal: #10B981 (Verde emerald)
- Secundario: #047857 (Verde oscuro)

**Diseño sugerido:**
- Icono: 💰 o símbolo de moneda
- Fondo: Verde gradiente
- Estilo: Minimalista, moderno

---

**Nota:** Los iconos son necesarios para que la PWA funcione correctamente al instalarla en móvil/desktop.
