# 🚀 Guía de Deploy - MoneyNest en Firebase

## 📋 Pasos Rápidos

### 1️⃣ **Preparar el Proyecto**

```bash
# Clonar o descargar el proyecto
git clone https://github.com/tu-usuario/moneynest.git
cd moneynest
```

### 2️⃣ **Instalar Firebase CLI**

```bash
# Instalar globalmente
npm install -g firebase-tools

# Verificar instalación
firebase --version
```

### 3️⃣ **Login en Firebase**

```bash
firebase login
```

Se abrirá tu navegador para autenticarte con Google.

### 4️⃣ **Crear Proyecto en Firebase Console**

1. Ve a: https://console.firebase.google.com/
2. Clic en "Agregar proyecto"
3. Nombre: `moneynest` (o el que prefieras)
4. Sigue los pasos
5. ¡Proyecto creado!

### 5️⃣ **Activar Servicios**

En Firebase Console:

#### **A) Activar Authentication**
1. Authentication → Get started
2. Sign-in method → Email/Password → Habilitar
3. Guardar

#### **B) Activar Firestore Database**
1. Firestore Database → Create database
2. Modo: Start in **production mode**
3. Ubicación: Elige la más cercana (europe-west1 para Europa)
4. Crear

#### **C) Copiar Configuración**
1. Project settings (⚙️) → General
2. Scroll down hasta "Your apps"
3. Clic en "</>" (Web)
4. Registrar app: "MoneyNest"
5. Firebase Hosting: ✅ Activar
6. Copiar el código de `firebaseConfig`

### 6️⃣ **Configurar el Proyecto**

#### **A) Editar index.html**

Busca esta sección (cerca de la línea 50-70):

```javascript
const firebaseConfig = {
  apiKey: "TU_API_KEY_AQUI",
  authDomain: "TU_AUTH_DOMAIN_AQUI",
  projectId: "TU_PROJECT_ID_AQUI",
  storageBucket: "TU_STORAGE_BUCKET_AQUI",
  messagingSenderId: "TU_MESSAGING_SENDER_ID_AQUI",
  appId: "TU_APP_ID_AQUI"
};
```

Reemplaza con tu configuración copiada del paso 5C.

#### **B) Guardar cambios**

```bash
git add index.html
git commit -m "Configurar Firebase"
```

### 7️⃣ **Inicializar Firebase en el Proyecto**

```bash
firebase init
```

Selecciona:
- **Firestore**: ✅ (con espacio)
- **Hosting**: ✅
- Presiona Enter

#### **Configuración Firestore:**
- Rules file: `firestore.rules` (Enter)
- Indexes file: `firestore.indexes.json` (Enter)

#### **Configuración Hosting:**
- Public directory: `public` (o `.` si quieres raíz)
- Single-page app: `Yes`
- GitHub auto deploys: `No` (por ahora)

### 8️⃣ **Organizar Archivos**

```bash
# Si elegiste "public" como directorio
mkdir public
mv index.html public/
mv manifest.json public/
mv service-worker.js public/

# O si elegiste raíz ".", ya está todo listo
```

### 9️⃣ **Deploy a Firebase**

```bash
firebase deploy
```

Espera 30-60 segundos...

✅ **¡Listo!**

Tu app estará en:
```
https://tu-proyecto-id.web.app
https://tu-proyecto-id.firebaseapp.com
```

---

## 🔧 Comandos Útiles

```bash
# Ver proyecto actual
firebase projects:list

# Cambiar de proyecto
firebase use nombre-proyecto

# Deploy solo hosting
firebase deploy --only hosting

# Deploy solo reglas Firestore
firebase deploy --only firestore:rules

# Ver logs
firebase hosting:sites:list

# Abrir en navegador
firebase open hosting:site
```

---

## 🔐 Configurar Reglas de Firestore

Después del primer deploy, las reglas ya están aplicadas desde `firestore.rules`.

Para verificar/editar:

1. Firebase Console → Firestore Database
2. Rules tab
3. Verás las reglas aplicadas
4. Si necesitas cambiar, edita `firestore.rules` y ejecuta:

```bash
firebase deploy --only firestore:rules
```

---

## 📊 Verificar Deployment

### ✅ Checklist Post-Deploy:

```bash
# 1. Abrir la app
firebase open hosting:site

# 2. Verificar funcionalidades:
☐ Login funciona
☐ Registro funciona
☐ Agregar ingreso guarda en Firestore
☐ Agregar gasto guarda en Firestore
☐ Presupuestos funcionan
☐ Gráficos se muestran
☐ Dark mode funciona
☐ Export CSV funciona

# 3. Ver Firestore Console
☐ Se crean colecciones users/
☐ Se guardan documentos
☐ Reglas de seguridad activas
```

---

## 🐛 Troubleshooting

### **Error: "Firebase app not initialized"**

**Causa:** No copiaste bien el firebaseConfig  
**Solución:** Revisa paso 6A, copia bien las credenciales

### **Error: "Permission denied" en Firestore**

**Causa:** Reglas de seguridad mal configuradas  
**Solución:**
```bash
firebase deploy --only firestore:rules
```

### **Error: "Auth domain not authorized"**

**Causa:** Dominio no autorizado  
**Solución:**
1. Firebase Console → Authentication → Settings
2. Authorized domains → Añade tu dominio `.web.app`

### **No se ve la app**

**Causa:** No se copió index.html a public/  
**Solución:**
```bash
cp index.html public/
firebase deploy
```

---

## 🔄 Actualizar la App

Cada vez que hagas cambios:

```bash
# 1. Editar archivos
# 2. Commit (opcional)
git add .
git commit -m "Mejorar dashboard"

# 3. Deploy
firebase deploy

# ✅ Cambios live en ~30 segundos
```

---

## 🌐 Dominio Personalizado

Para usar tu propio dominio (ejemplo.com):

```bash
# 1. En Firebase Console
# Hosting → Add custom domain
# Sigue instrucciones para DNS

# 2. O por CLI:
firebase hosting:sites:create tu-dominio
firebase target:apply hosting production tu-dominio
firebase deploy --only hosting:production
```

---

## 📱 Configurar PWA

La PWA ya está configurada con:
- ✅ `manifest.json`
- ✅ `service-worker.js`
- ✅ Iconos (añadir en carpeta `/icons/`)

Para que funcione 100%:

1. **Generar iconos:**
   - Usa: https://realfavicongenerator.net/
   - Sube logo de MoneyNest
   - Descarga y coloca en `/public/icons/`

2. **Verificar PWA:**
   - Chrome DevTools → Lighthouse
   - Run audit → PWA
   - Score debe ser 90-100

---

## 📈 Monitoreo

### **Ver estadísticas:**

```bash
# Abrir Analytics
firebase open analytics

# Ver logs
firebase functions:log
```

### **Configurar Analytics:**

1. Firebase Console → Analytics
2. Enable Google Analytics
3. Ya está capturando datos automáticamente

---

## 🔒 Seguridad Adicional

### **Limitar acceso por dominio:**

En Firebase Console:

1. Authentication → Settings → Authorized domains
2. Quita dominios que no uses
3. Solo deja: `tu-proyecto.web.app`, `localhost`

### **Activar App Check:**

```bash
# Instalar SDK
# En index.html, añade antes de </head>:
<script src="https://www.gstatic.com/firebasejs/9.x.x/firebase-app-check.js"></script>

# Configurar en JS
const appCheck = firebase.appCheck();
appCheck.activate('tu-site-key');
```

---

## ✅ Listo para Producción

Tu app MoneyNest está:
- ✅ Desplegada en Firebase
- ✅ Con HTTPS automático
- ✅ Con CDN global
- ✅ Con reglas de seguridad
- ✅ Como PWA instalable
- ✅ Con autenticación segura

**URL final:**
```
https://tu-proyecto.web.app
```

---

## 🆘 Soporte

**¿Problemas?**

1. Revisa docs oficiales: https://firebase.google.com/docs/hosting
2. Stack Overflow: busca "firebase hosting"
3. GitHub Issues del proyecto

---

**¡MoneyNest está LIVE! 🎉**
