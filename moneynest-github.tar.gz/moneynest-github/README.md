# 💰 MoneyNest - Gestión Financiera Personal Premium

> Aplicación web profesional para control total de finanzas personales, inversiones y objetivos financieros.

![MoneyNest](https://img.shields.io/badge/version-1.0.0-green.svg)
![License](https://img.shields.io/badge/license-MIT-blue.svg)
![Firebase](https://img.shields.io/badge/Firebase-Hosting-orange.svg)

---

## 🚀 Características Principales

### 💸 Gestión de Finanzas
- **Control de Ingresos**: Registro detallado con categorías y fechas
- **Control de Gastos**: Seguimiento completo de gastos con categorías
- **Inversiones**: Monitoreo de portafolio de inversión
- **Presupuestos**: Planificación mensual con alertas
- **Objetivos de Ahorro**: Define y alcanza tus metas financieras

### 📊 Analytics y Reportes
- **Dashboard Interactivo**: Visualiza tu situación financiera en tiempo real
- **Gráficos Dinámicos**: Charts.js para visualización de datos
- **Balance Automático**: Cálculo instantáneo de balance neto
- **Tendencias**: Análisis de patrones de gasto e ingreso

### 🔐 Seguridad y Privacidad
- **Autenticación Firebase**: Login seguro con email/password
- **Datos Encriptados**: Firestore con reglas de seguridad
- **Sistema PIN**: Capa adicional de protección
- **Sesiones Persistentes**: Mantén tu sesión activa de forma segura

### 📱 PWA - Progressive Web App
- **Instalable**: Añade a pantalla de inicio (iOS/Android)
- **Offline Ready**: Funciona sin conexión
- **Responsive**: Perfecto en móvil, tablet y desktop
- **Fast Loading**: Optimizado para carga rápida

### 🎨 Diseño Premium
- **Flare Oasis Style**: Diseño moderno y minimalista
- **Dark Mode**: Tema oscuro para reducir fatiga visual
- **Animaciones**: Micro-interacciones suaves
- **Iconos**: Sistema de iconos coherente

### 📤 Exportación de Datos
- **CSV Export**: Descarga tus datos en formato CSV
- **PDF Reports**: Genera reportes profesionales
- **Backup**: Respaldo completo de datos

---

## 🛠️ Tecnologías

```
Frontend:
├── HTML5
├── CSS3 (Variables CSS, Flexbox, Grid)
├── JavaScript (ES6+)
└── Chart.js v4.4.1

Backend & Database:
├── Firebase Authentication
├── Cloud Firestore
└── Firebase Hosting

PWA:
├── Service Worker
├── Manifest.json
└── Offline Support
```

---

## 📦 Instalación y Deploy

### **Opción 1: Firebase Hosting (Recomendado)**

#### 1. **Prerrequisitos**
```bash
# Instalar Node.js (si no lo tienes)
https://nodejs.org/

# Instalar Firebase CLI
npm install -g firebase-tools
```

#### 2. **Clonar el repositorio**
```bash
git clone https://github.com/tu-usuario/moneynest.git
cd moneynest
```

#### 3. **Configurar Firebase**
```bash
# Login en Firebase
firebase login

# Inicializar proyecto
firebase init

# Selecciona:
# ✓ Hosting
# ✓ Firestore
# ✓ Authentication
```

#### 4. **Configurar credenciales**
Edita `index.html` y añade tu configuración de Firebase:

```javascript
const firebaseConfig = {
  apiKey: "TU_API_KEY",
  authDomain: "TU_AUTH_DOMAIN",
  projectId: "TU_PROJECT_ID",
  storageBucket: "TU_STORAGE_BUCKET",
  messagingSenderId: "TU_MESSAGING_SENDER_ID",
  appId: "TU_APP_ID"
};
```

#### 5. **Configurar reglas de Firestore**
Copia el contenido de `firestore.rules` en Firebase Console:

```javascript
rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {
    match /users/{userId} {
      allow read, write: if request.auth != null && request.auth.uid == userId;
      
      match /ingresos/{document=**} {
        allow read, write: if request.auth != null && request.auth.uid == userId;
      }
      
      match /gastos/{document=**} {
        allow read, write: if request.auth != null && request.auth.uid == userId;
      }
      
      match /inversiones/{document=**} {
        allow read, write: if request.auth != null && request.auth.uid == userId;
      }
    }
  }
}
```

#### 6. **Deploy**
```bash
# Deploy a Firebase Hosting
firebase deploy

# Tu app estará disponible en:
# https://tu-proyecto.web.app
```

---

### **Opción 2: Netlify**

```bash
# Instalar Netlify CLI
npm install -g netlify-cli

# Deploy
netlify deploy --prod

# Arrastra el archivo index.html
```

---

### **Opción 3: GitHub Pages**

1. Sube el código a GitHub
2. Ve a Settings → Pages
3. Selecciona la rama main
4. ¡Listo!

**Nota:** Necesitarás configurar Firebase externamente

---

## 🔧 Configuración

### **1. Firebase Project**

1. Ve a [Firebase Console](https://console.firebase.google.com/)
2. Crea un nuevo proyecto
3. Activa **Authentication** → Email/Password
4. Activa **Cloud Firestore**
5. Copia las credenciales
6. Pégalas en `index.html`

### **2. Firestore Database**

Estructura de colecciones:

```
users/
  └── {userId}/
      ├── profile (doc)
      ├── ingresos/ (collection)
      ├── gastos/ (collection)
      ├── inversiones/ (collection)
      ├── presupuestos/ (collection)
      └── objetivos/ (collection)
```

### **3. Variables de Entorno**

Si usas un build system, puedes usar variables:

```javascript
// .env.local
VITE_FIREBASE_API_KEY=your_api_key
VITE_FIREBASE_AUTH_DOMAIN=your_domain
VITE_FIREBASE_PROJECT_ID=your_project_id
```

---

## 📖 Uso

### **Primera vez**

1. Abre la app
2. Clic en "Registrarse"
3. Ingresa email y password
4. ¡Empieza a usar MoneyNest!

### **Agregar Ingreso**

1. Ve a la sección "Ingresos"
2. Clic en "+"
3. Completa: Concepto, Monto, Categoría, Fecha
4. Guardar

### **Crear Presupuesto**

1. Ve a "Presupuestos"
2. Clic en "Nuevo Presupuesto"
3. Define categoría, monto y período
4. Recibe alertas al alcanzar límites

### **Exportar Datos**

1. Ve a Configuración
2. Clic en "Exportar a CSV"
3. Descarga el archivo
4. Úsalo en Excel/Google Sheets

---

## 🎯 Roadmap

### v1.1 (Próximamente)
- [ ] Modo multi-moneda
- [ ] Sincronización con cuentas bancarias
- [ ] Notificaciones push
- [ ] Recordatorios de pagos

### v1.2
- [ ] Colaboración (compartir con pareja)
- [ ] Categorías personalizadas
- [ ] Temas de color personalizables
- [ ] Widgets de dashboard configurables

### v2.0
- [ ] App nativa (iOS/Android)
- [ ] Escaneo de recibos (OCR)
- [ ] IA para análisis predictivo
- [ ] Integración con criptomonedas

---

## 🤝 Contribuir

¡Las contribuciones son bienvenidas!

1. Fork el proyecto
2. Crea una rama (`git checkout -b feature/AmazingFeature`)
3. Commit tus cambios (`git commit -m 'Add some AmazingFeature'`)
4. Push a la rama (`git push origin feature/AmazingFeature`)
5. Abre un Pull Request

---

## 📝 Estructura del Proyecto

```
moneynest/
├── index.html              # App principal (PWA)
├── manifest.json           # PWA Manifest
├── service-worker.js       # Service Worker para offline
├── firestore.rules         # Reglas de seguridad
├── firebase.json           # Configuración Firebase
├── README.md               # Este archivo
├── LICENSE                 # Licencia MIT
└── .github/
    └── workflows/
        └── deploy.yml      # CI/CD automatizado
```

---

## 🔒 Seguridad

- ✅ Autenticación requerida para todas las operaciones
- ✅ Reglas de Firestore por usuario
- ✅ Validación de datos en cliente y servidor
- ✅ Sesiones seguras con Firebase Auth
- ✅ Encriptación HTTPS en tránsito
- ✅ Sistema PIN opcional

**Reporta vulnerabilidades a:** security@moneynest.app

---

## 📄 Licencia

MIT License - Ver [LICENSE](LICENSE) para más detalles

---

## 👨‍💻 Autor

**Invest Grid**
- Website: [investgrid.com](https://investgrid.com)
- Email: hola@investgrid.com

---

## 🙏 Agradecimientos

- [Chart.js](https://www.chartjs.org/) - Gráficos
- [Firebase](https://firebase.google.com/) - Backend
- [Inter Font](https://rsms.me/inter/) - Tipografía
- [Heroicons](https://heroicons.com/) - Iconos

---

## 📱 Screenshots

### Dashboard
![Dashboard](screenshots/dashboard.png)

### Gestión de Gastos
![Gastos](screenshots/gastos.png)

### Presupuestos
![Presupuestos](screenshots/presupuestos.png)

---

## 🐛 Bugs Conocidos

- Ninguno reportado actualmente

**Reporta bugs en:** [Issues](https://github.com/tu-usuario/moneynest/issues)

---

## 📊 Stats

![GitHub stars](https://img.shields.io/github/stars/tu-usuario/moneynest?style=social)
![GitHub forks](https://img.shields.io/github/forks/tu-usuario/moneynest?style=social)
![GitHub watchers](https://img.shields.io/github/watchers/tu-usuario/moneynest?style=social)

---

## 💰 Precio

**MoneyNest Premium** - €1.00 (Oferta de lanzamiento)

Precio regular: €29.99

[Comprar ahora](https://investgrid.com/productos)

---

**¿Te gusta MoneyNest? ¡Dale una ⭐ en GitHub!**
