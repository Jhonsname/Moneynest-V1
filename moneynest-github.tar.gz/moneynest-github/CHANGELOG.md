# 📋 Changelog

Todos los cambios importantes del proyecto serán documentados aquí.

El formato está basado en [Keep a Changelog](https://keepachangelog.com/en/1.0.0/).

---

## [1.0.0] - 2026-01-22

### 🎉 Lanzamiento Inicial

#### ✨ Características Principales
- **Gestión Financiera Completa**
  - Control de ingresos con categorías
  - Seguimiento de gastos detallado
  - Monitoreo de inversiones
  - Sistema de presupuestos mensuales
  - Objetivos de ahorro con seguimiento

- **Dashboard Interactivo**
  - Gráficos con Chart.js
  - Balance en tiempo real
  - Estadísticas por categoría
  - Tendencias mensuales

- **Autenticación y Seguridad**
  - Firebase Authentication
  - Firestore Database
  - Reglas de seguridad robustas
  - Sistema PIN opcional

- **PWA - Progressive Web App**
  - Instalable en móvil y desktop
  - Funciona offline
  - Service Worker configurado
  - Manifest completo

- **Diseño Premium**
  - Estilo Flare Oasis minimalista
  - Dark mode
  - Responsive 100%
  - Animaciones suaves

- **Exportación**
  - CSV export
  - PDF reports
  - Backup de datos

#### 🔧 Técnico
- Firebase Authentication v10
- Cloud Firestore
- Chart.js v4.4.1
- Service Worker v1.0.0
- PWA Manifest completo

---

## [Próximas Versiones]

### v1.1.0 (Planeado)
- [ ] Modo multi-moneda
- [ ] Notificaciones push
- [ ] Recordatorios de pagos
- [ ] Mejoras en gráficos

### v1.2.0 (Planeado)
- [ ] Colaboración (compartir con pareja)
- [ ] Categorías personalizadas
- [ ] Temas de color custom
- [ ] Widgets configurables

### v2.0.0 (Futuro)
- [ ] App nativa iOS/Android
- [ ] OCR para recibos
- [ ] IA para análisis predictivo
- [ ] Integración crypto

---

## Formato de Versiones

Usamos [Semantic Versioning](https://semver.org/):

- **MAJOR**: Cambios incompatibles con API anterior
- **MINOR**: Nueva funcionalidad compatible
- **PATCH**: Correcciones de bugs

### Tipos de Cambios:
- `Added` - Nuevas features
- `Changed` - Cambios en funcionalidad existente
- `Deprecated` - Features que se eliminarán pronto
- `Removed` - Features eliminadas
- `Fixed` - Bugs corregidos
- `Security` - Vulnerabilidades corregidas

---

## Ejemplo de entrada futura:

```markdown
## [1.0.1] - 2026-01-30

### Fixed
- Corregido cálculo de balance cuando hay inversiones
- Solucionado problema con export CSV en Safari

### Changed
- Mejorado rendimiento de gráficos con muchos datos
```

---

**Fecha de última actualización:** 2026-01-22
